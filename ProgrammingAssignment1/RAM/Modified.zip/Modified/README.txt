**********************************************
*****CS4760 Operating System - Project 1******
**********************************************

---------------------------------------------------
---------------------------------------------------
Run the below commands in the order mentioned 
to execute the project:

1 ls

2 make

3 ./output
----------------------------------------------------
Use the below command line arguements:

-h for HELP
-n to Enter a numeric value
-l to rename  the logfile
----------------------------------------------------
Example:

-n 100
  or
-l testLog.txt
----------------------------------------------------
*'clear' to clear the screen
*'make clean' to clear the make file
----------------------------------------------------
----------------------------------------------------  
 

